package dynamic_app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class Signin extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String user = req.getParameter("user");
		String password = req.getParameter("password");

		Connection con = null;
		PreparedStatement ps = null;
		String qry = null;
		ResultSet rs = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo?user=root&&password=root");

			qry = "select * from user where name=? and password=?";

			ps = con.prepareStatement(qry);
			ps.setString(1, user);
			ps.setString(2, password);
			rs = ps.executeQuery();
			System.out.println("signin");

			if (rs.next()) {
//				System.out.println("done11");
				int id = rs.getInt("id");
				String userName = rs.getString("name");
				String email = rs.getString("email");
				int age = rs.getInt("age");
				String password1 = rs.getString("password");

				HttpSession session = req.getSession();
				session.setAttribute("id", id);
				session.setAttribute("name", userName);
				session.setAttribute("mail", email);
				session.setAttribute("age", age);
				session.setAttribute("password", password1);

				RequestDispatcher rd = req.getRequestDispatcher("home");
				rd.forward(req, resp);

			} else {

				System.out.println("not done");
				PrintWriter pw = resp.getWriter();
				pw.println("<html><body>");
				pw.println("<h1 class='error'>user details not found</h1>");
				pw.println("</body></html>");
				RequestDispatcher rd = req.getRequestDispatcher("signin.html");
				rd.include(req, resp);

			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
