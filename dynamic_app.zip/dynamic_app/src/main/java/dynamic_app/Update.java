package dynamic_app;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/modify")
public class Update extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String ac = req.getParameter("action");
	
		PrintWriter pw = resp.getWriter();
		
		
			if(ac.equals("edit")) {
				System.out.println("edit");
				
				HttpSession session = req.getSession();
				int id = (int) session.getAttribute("id");
				String name = (String) session.getAttribute("name");
				String mail = (String) session.getAttribute("mail");
				int age = (int) session.getAttribute("age");
				String password = (String) session.getAttribute("password");
				
				session.setAttribute("id",id);
				
				pw.println("<!DOCTYPE html>\r\n"
						+ "<html lang='en'>\r\n"
						+ "	<head>\r\n"
						+ "		<meta charset='UTF-8' />\r\n"
						+ "		<meta name='viewport' content='width=device-width, initial-scale=1.0' />\r\n"
						+ "		<title>Update Details</title>\r\n"
						+ "	</head>\r\n"
						+ "	<body>\r\n"
						+ "		<div class='container'>\r\n"
						+ "			<form action='save' method='get'>\r\n"
						+ "				<table border='0' height='400px' width='300px'>\r\n"
						+ "					<thead>\r\n"
						+ "						<td colspan='2'><h3>Employee-Id: "+id+"</h3></td>\r\n"
						+ "					</thead>\r\n"
						+ "					<tr>\r\n"
						+ "						<td>\r\n"
						+ "							<label for='name'>Name:</label>\r\n"
						+ "						</td>\r\n"
						+ "						<td>\r\n"
						+ "							<input type='text' id='name' name='name' value='"+name+"'  />\r\n"
						+ "						</td>\r\n"
						+ "					</tr>\r\n"
						+ "					<tr>\r\n"
						+ "						<td>\r\n"
						+ "							<label for='email'>Email:</label>\r\n"
						+ "						</td>\r\n"
						+ "						<td>\r\n"
						+ "							<input type='text' id='email' name='email' value='"+mail+"'  />\r\n"
						+ "						</td>\r\n"
						+ "					</tr>\r\n"
						+ "					<tr>\r\n"
						+ "						<td>\r\n"
						+ "							<label for='age'>Age:</label>\r\n"
						+ "						</td>\r\n"
						+ "						<td>\r\n"
						+ "							<input type='text' id='age' name='age' value='"+age+"'  />\r\n"
						+ "						</td>\r\n"
						+ "					</tr>\r\n"
						+ "					<tr>\r\n"
						+ "						<td>\r\n"
						+ "							<label for='password'>Password:</label>\r\n"
						+ "						</td>\r\n"
						+ "						<td>\r\n"
						+ "							<input type='text' id='password' name='password' value='"+password+"'  />\r\n"
						+ "						</td>\r\n"
						+ "					</tr>\r\n"
						+ "					<tr>\r\n"
						+ "						<td colspan='2'>\r\n"
						+ "							<button>save</button>\r\n"
						+ "						</td>\r\n"
						+ "					</tr>\r\n"
						+ "				</table>\r\n"
						+ "			</form>\r\n"
						+ "		</div>\r\n"
						+ "\r\n"
						+ "		<style>\r\n"
						+ "			* {\r\n"
						+ "					padding: 0;\r\n"
						+ "					margin: 0;\r\n"
						+ "				}\r\n"
						+ "				\r\n"
						+ "				body {\r\n"
						+ "					height: 100vh;\r\n"
						+ "					display: flex;\r\n"
						+ "					flex-direction: column;\r\n"
						+ "					align-items: center;\r\n"
						+ "					justify-content: center;\r\n"
						+ "					background-color: gainsboro;\r\n"
						+ "				}\r\n"
						+ "				.container {\r\n"
						+ "					background-color: ivory;\r\n"
						+ "					box-shadow: 1px 1px 2px rgba(0, 0, 0, .5),\r\n"
						+ "					-1px -1px 2px rgba(0, 0, 0, .5);\r\n"
						+ "					padding: 20px 10px;\r\n"
						+ "					border-radius: 20px;\r\n"
						+ "					text-align: center;\r\n"
						+ "				}\r\n"
						+ "				form {\r\n"
						+ "					text-align: center;\r\n"
						+ "					font-size: 18px;\r\n"
						+ "					display: flex;\r\n"
						+ "					flex-direction: column;\r\n"
						+ "					align-items: center;\r\n"
						+ "					justify-content: center;\r\n"
						+ "					padding:30px 20px;\r\n"
						+ "				}\r\n"
						+ "				\r\n"
						+ "				input {\r\n"
						+ "					padding: 8px 10px;\r\n"
						+ "					font-size: 15px;\r\n"
						+ "					height: 25px;\r\n"
						+ "					width: 300px;\r\n"
						+ "					background-color: ivory;\r\n"
						+ "					border:1px solid black;\r\n"
						+ "					border-radius: 10px;\r\n"
						+ "				}\r\n"
						+ "				\r\n"
						+ "				button {\r\n"
						+ "					padding: 10px 20px;\r\n"
						+ "					font-size: 15px;\r\n"
						+ "					font-weight: 700;\r\n"
						+ "					border-radius: 10px;\r\n"
						+ "					border: 1px solid black;\r\n"
						+ "					cursor: pointer;\r\n"
						+ "					margin: 10px 15px;\r\n"
						+ "					background-color: ivory;\r\n"
						+ "				}\r\n"
						+ "			\r\n"
						+ "			</style>\r\n"
						+ "	</body>\r\n"
						+ "</html>");
			}else {
				RequestDispatcher rd = req.getRequestDispatcher("delete.html");
				rd.forward(req, resp);
			}
				
	}
}
