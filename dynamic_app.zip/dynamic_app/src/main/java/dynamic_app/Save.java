package dynamic_app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/save")
public class Save extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Connection con = null;
		PreparedStatement ps = null;
		String qry = "";
		HttpSession session = req.getSession();
		int id = (int) session.getAttribute("id");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo?user=root&&password=root");
			qry = "update user set name=?, email=?, age=?, password=? where id = ?";
			ps = con.prepareStatement(qry);
			
			String uname = req.getParameter("name");
			String email = req.getParameter("email");
			int uage = Integer.parseInt(req.getParameter("age"));
			String upassword = req.getParameter("password");
			
			ps.setString(1, uname);
			ps.setString(2, email);
			ps.setInt(3, uage);
			ps.setString(4, upassword);
			ps.setInt(5, id);
			ps.executeUpdate();
			System.out.println("saved");
			
			PrintWriter pw = resp.getWriter();
			pw.println("<html><body>");
			pw.println("<div class='container'>"
					+ "<h1>Details are Updated Sucessfully:)</h1>");
			pw.println("<a href='./signin.html'><button>Login</button></a>"
					+ "</div>"
					+ "<style>\r\n"
					+ "			* {\r\n"
					+ "					padding: 0;\r\n"
					+ "					margin: 0;\r\n"
					+ "				}\r\n"
					+ "				\r\n"
					+ "				body {\r\n"
					+ "					height: 100vh;\r\n"
					+ "					display: flex;\r\n"
					+ "					flex-direction: column;\r\n"
					+ "					align-items: center;\r\n"
					+ "					justify-content: center;\r\n"
					+ "					background-color: gainsboro;\r\n"
					+ "				}\r\n"
					+ "				.container {\r\n"
					+ "					background-color: ivory;\r\n"
					+ "					box-shadow: 1px 1px 2px rgba(0, 0, 0, .5),\r\n"
					+ "					-1px -1px 2px rgba(0, 0, 0, .5);\r\n"
					+ "					padding: 20px 10px;\r\n"
					+ "					border-radius: 20px;\r\n"
					+ "					text-align: center;\r\n"
					+ "					}"
					+ 					"button {\r\n"
					+ "					padding: 10px 20px;\r\n"
					+ "					font-size: 15px;\r\n"
					+ "					font-weight: 700;\r\n"
					+ "					border-radius: 10px;\r\n"
					+ "					border: 1px solid black;\r\n"
					+ "					cursor: pointer;\r\n"
					+ "					margin: 10px 15px;\r\n"
					+ "					background-color: gainsboro;\r\n"
					+ "				}"
					+ "</style>");
			
			pw.println("</body></html>");
			
			

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
